# AI/ML Applications in Related RNA-seq Analysis Tasks
## Part B: Specific Applications and Evidence

**Document Date:** November 2025

**Context:** Detailed examination of ML/AI methods successfully applied to RNA-seq analysis tasks. Each application documents the traditional approach, ML innovation, success assessment, and supporting references.

**Important:** This document should be read **after** Part A (Methodological Considerations), which provides critical context about home team advantage, publication bias, and realistic performance expectations.

---

## Executive Summary

This document catalogs specific AI/ML applications in RNA-seq analysis, systematically documenting for each:

1. **The traditional non-ML/AI approach** being updated or replaced
2. **The specific ML/AI method** applied
3. **How success is assessed** (metrics, comparisons, benchmarks)
4. **Supporting literature** with full citations

**Key finding:** While ML has been successfully applied to gene selection, single-cell analysis, and data modeling, **no work has specifically applied AI/ML to enhance RUV-based normalization** despite RUV's strong theoretical foundation and empirical success.

**Critical reminder from Part A:** Reported performance improvements should be viewed as optimistic upper bounds. True performance on independent data is likely 30-50% lower than published claims.

---

## Table of Contents

1. [Gene Selection and Feature Extraction](#1-gene-selection-and-feature-extraction)
2. [Single-Cell RNA-seq Analysis](#2-single-cell-rna-seq-analysis)
3. [Batch Correction Methods (Non-RUV)](#3-batch-correction-methods-non-ruv)
4. [General RNA-seq Processing Tasks](#4-general-rna-seq-processing-tasks)
5. [Summary and Implications](#5-summary-and-implications)
6. [References](#references)

---

## 1. Gene Selection and Feature Extraction

### 1.1 Traditional Approach: Differential Expression Analysis

**Method:** Statistical hypothesis testing to identify genes with significant expression differences between conditions.

**Common Tools:**
- DESeq2: Uses negative binomial generalized linear models
- edgeR: Empirical Bayes methods with negative binomial distribution
- limma: Linear models for microarray and RNA-seq
- t-tests, ANOVA for simpler designs

**Process:**
1. Model gene expression counts with appropriate distribution
2. Test each gene independently for differential expression
3. Adjust p-values for multiple testing (FDR control)
4. Rank genes by statistical significance

**Success Metrics:**
- False discovery rate (FDR)
- Number of genes called significant
- Overlap with known disease-associated genes
- Validation via qPCR or independent cohorts
- Biological pathway enrichment

**Limitations:**
- Tests genes independently (misses gene-gene interactions)
- Linear assumptions may not capture complex relationships
- May miss genes with moderate effects that act in combination
- Requires large sample sizes for reliable statistical power

---

### 1.2 ML/AI Approach #1: Random Forests for Gene Ranking

#### The Innovation

<cite>Wenric and Shemirani (2018)</cite> demonstrated that Random Forest (RF) classification could outperform traditional differential expression analysis for identifying disease-relevant genes in RNA-seq data.

#### Method Details

**Algorithm:** Random Forest classification with permutation-based variable importance

**Training Strategy:**
- Train RF classifier to distinguish cases from controls
- Use gene expression values as features
- Extract permutation importance scores for each gene
- Importance = drop in classification accuracy when gene values are randomly shuffled

**Key Advantage:** 
- Captures non-linear relationships between genes
- Models gene-gene interactions automatically
- Multivariate approach considers all genes simultaneously
- More robust to noise than univariate testing

#### Assessment of Success

**Comparison Setup:**
- RF gene rankings vs. differential expression (DE) rankings
- Both evaluated on ability to predict survival outcomes
- Validation performed on independent cohorts

**Performance Metrics:**
- Survival prediction accuracy (concordance index)
- Hazard ratios for gene signatures
- Cross-validation performance
- Generalization to external datasets

**Key Finding:** 
The RF-based method **outperformed differential expression analysis in 9 out of 12 cancer datasets** for identifying survival-associated genes. This demonstrates ML's ability to capture gene-disease associations missed by univariate statistical testing.

**Interpretation:**
RF's superior performance likely stems from its ability to:
- Model complex non-linear relationships between gene expression and outcome
- Automatically detect gene-gene interactions
- Handle high-dimensional feature spaces without explicit feature selection
- Reduce overfitting through ensemble averaging

#### Supporting Reference

**Primary Citation:**
Wenric, S. & Shemirani, R. (2018). Using Supervised Learning Methods for Gene Selection in RNA-Seq Case-Control Studies. *Frontiers in Genetics*, 9:297. https://doi.org/10.3389/fgene.2018.00297

**Key Excerpts from Paper:**
- "Here, we explore the use of supervised learning methods to rank large ensembles of genes defined by their expression values measured with RNA-Seq in a typical 2 classes sample set"
- "These rankings were compared with the results of a differential expression analysis, with all three gene rankings being evaluated through survival analysis on a validation cohort"
- "The results have shown that the random forests-based method...outperformed the differential expression-based method for 9...out of the 12 data sets analyzed"

---

### 1.3 ML/AI Approach #2: Variational Autoencoders for Gene Selection

#### The Innovation

The same study by <cite>Wenric and Shemirani (2018)</cite> introduced the **Extreme Pseudo-Samples (EPS) pipeline**, using Variational Autoencoders (VAEs) to generate synthetic samples for enhanced gene selection.

#### Method Details

**Algorithm:** Variational Autoencoder (VAE) for generative modeling

**Architecture:**
```
Encoder: Gene expression → Latent distribution parameters (μ, σ)
Latent sampling: z ~ N(μ, σ)
Decoder: Latent vector z → Reconstructed expression
```

**VAE Key Properties:**
- Learns probabilistic mapping from data to latent space
- Can generate new samples by sampling from latent distribution
- Latent space has smooth, continuous structure
- Enables interpolation and extrapolation in data space

**EPS Pipeline:**
1. Train VAE on case and control samples
2. Identify latent space regions corresponding to extreme cases/controls
3. Generate "extreme pseudo-samples" from these regions
4. Extract gene importance weights from pseudo-samples
5. Rank genes by their contribution to extreme phenotypes

**Traditional Alternative:** 
No direct analog in traditional DE analysis. Closest approaches:
- Bootstrapping: Resamples existing data (doesn't explore latent space)
- SMOTE: Creates synthetic samples via interpolation (linear, not learned)

**Key Advantage:**
- Explores extreme regions of biological variation underrepresented in data
- Generates novel samples that maintain biological plausibility
- Captures complex non-linear manifold of gene expression space
- Can identify genes important for extreme phenotypes

#### Assessment of Success

**Evaluation Strategy:**
- Compare EPS gene rankings to differential expression rankings
- Test both on survival prediction in independent validation cohorts
- Measure which method better identifies prognostically relevant genes

**Performance Metrics:**
- Survival prediction accuracy
- Concordance index
- Hazard ratios
- Cross-dataset validation

**Key Finding:**
EPS **outperformed differential expression analysis in 8 out of 12 cancer datasets**. While slightly lower than RF (9/12), this still demonstrates substantial improvement over traditional methods.

**Why VAEs Work Here:**
- VAEs learn a meaningful latent representation where similar biology clusters
- Sampling from extreme regions identifies genes driving phenotypic differences
- Generative nature allows exploring counterfactual scenarios
- Probabilistic framework provides uncertainty estimates

#### Supporting References

**Primary Citation:**
Wenric, S. & Shemirani, R. (2018). Using Supervised Learning Methods for Gene Selection in RNA-Seq Case-Control Studies. *Frontiers in Genetics*, 9:297. https://doi.org/10.3389/fgene.2018.00297

**Key Excerpts:**
- "We define the EPS (extreme pseudo-samples) pipeline, making use of VAEs (Variational Autoencoders) and regressors to extract a ranking of genes"
- "Variational Autoencoders could be used to generate pseudo-samples mimicking the properties of real samples, albeit with extreme localizations in latent space"
- "Using the feature weights of said pseudo-samples allowed to obtain a ranking of genes"

---

### 1.4 Additional VAE Applications in RNA-seq

#### scVAE: Single-Cell Expression Modeling

<cite>Grønbech et al. (2020)</cite> developed **scVAE** specifically for modeling single-cell and bulk RNA-seq data.

**Key Innovations:**
- Zero-inflated negative binomial (ZINB) likelihood for scRNA-seq
- Gaussian Mixture VAE (GMVAE) with built-in clustering
- Handles dropout events explicitly in the model

**Traditional Comparison:**
- Compared against factor analysis (FA)
- Compared against PCA + k-means
- Compared against other scRNA-seq methods (Seurat, scVI)

**Success Metrics:**
- Log-likelihood lower bounds (measure of model fit)
- Rand index for clustering accuracy (when cell types known)
- Visual separation in latent space (t-SNE/UMAP)

**Key Finding:**
GMVAE achieved **higher log-likelihood lower bounds** on all datasets tested and showed **clearer separation of cell types** in latent space compared to linear methods.

**Reference:**
Grønbech, C.H., Vording, M.F., Timshel, P.N., Sønderby, C.K., Pers, T.H., & Winther, O. (2020). scVAE: Variational auto-encoders for single-cell gene expression data. *Bioinformatics*, 36(16):4415-4422. https://doi.org/10.1093/bioinformatics/btaa293

---

#### Tybalt: Cancer Transcriptome VAE

<cite>Way and Greene (2017)</cite> applied VAEs to TCGA pan-cancer RNA-seq data, creating the "Tybalt" model.

**Key Findings:**
- Decoder weights captured gene contributions to learned features
- Latent space encoded biologically meaningful patterns:
  - Cancer type separation
  - Tumor purity gradients
  - Pathway activation states
- Could generate synthetic expression profiles
- Enabled exploration of gene expression manifold

**Traditional Comparison:**
- Compared to PCA (linear dimensionality reduction)
- Compared to t-SNE (non-linear but non-generative)
- Compared to independent component analysis (ICA)

**Success Metrics:**
- Reconstruction accuracy
- Biological interpretability of latent dimensions
- Correlation with known biological variables
- Literature validation of gene-feature associations

**Reference:**
Way, G.P. & Greene, C.S. (2017). Extracting a biologically relevant latent space from cancer transcriptomes with variational autoencoders. *Pacific Symposium on Biocomputing*, 23:80-91. https://doi.org/10.1142/9789813235533_0008

---

#### Foundational VAE Work

**Reference:**
Kingma, D.P. & Welling, M. (2013). Auto-encoding variational Bayes. *arXiv preprint* arXiv:1312.6114. https://arxiv.org/abs/1312.6114

This seminal paper introduced VAEs and established their mathematical framework, enabling all subsequent applications in genomics.

---

### 1.5 ML/AI Approach #3: Deep Learning Feature Selection

#### The Approach

Multiple studies have applied deep neural networks with integrated feature selection for identifying prognostic genes directly from expression data.

**Traditional Alternative:**
Cox proportional hazards regression with penalization:
- LASSO (L1 regularization): Promotes sparsity, selects subset of genes
- Elastic net (L1 + L2): Balances feature selection and grouping
- Ridge regression (L2): Shrinks coefficients but doesn't eliminate features

#### Deep Learning Innovations

**Architecture Components:**
- Feature selection layers (attention mechanisms, gating)
- Deep hidden layers for non-linear transformations
- Survival loss functions (Cox partial likelihood, ranking loss)
- End-to-end training on survival outcomes

**Key Advantages:**
- Automatic capture of gene-gene interactions
- Non-linear transformations of expression space
- Joint optimization of feature selection and prediction
- Can integrate multiple data modalities

**Traditional Comparison:**
- Benchmark against Cox regression (LASSO, elastic net)
- Compare to Random Survival Forests
- Evaluate against clinical prognostic models

#### Assessment of Success

**Metrics Used:**
- Concordance index (C-index): Rank correlation of predicted vs. observed survival
- Integrated Brier Score: Prediction error over time
- Time-dependent AUC: Classification accuracy at specific timepoints
- Calibration plots: Agreement between predicted and observed survival

**General Finding Across Studies:**
Deep learning methods often **match or exceed traditional survival models** in prediction accuracy, while also identifying novel prognostic gene signatures that differ from those found by univariate Cox regression.

#### Supporting References

**Cox-nnet:**
Ching, T., Zhu, X., & Garmire, L.X. (2018). Cox-nnet: An artificial neural network method for prognosis prediction of high-throughput omics data. *PLoS Computational Biology*, 14(4):e1006076. https://doi.org/10.1371/journal.pcbi.1006076

**General ML Methods Review:**
Swan, A.L., Mobasheri, A., Allaway, D., Liddell, S., & Bacardit, J. (2013). Application of machine learning to proteomics data: classification and biomarker identification in postgenomics biology. *OMICS*, 17(12):595-610. https://doi.org/10.1089/omi.2013.0017

---

## 2. Single-Cell RNA-seq Analysis

Single-cell RNA-seq presents unique computational challenges due to high dimensionality, extreme sparsity (dropout events), and the need to identify rare cell populations. This section documents how ML/AI has transformed scRNA-seq analysis.

---

### 2.1 Cell Type Annotation

#### Traditional Approach: Manual Cluster Interpretation

**Process:**
1. Cluster cells using graph-based methods (Louvain, Leiden) or k-means
2. Visualize clusters with UMAP or t-SNE
3. For each cluster:
   - Perform differential expression analysis vs. all other cells
   - Identify top marker genes
   - Manually look up marker genes in literature
   - Compare to known cell type markers (e.g., CD3 for T cells)
   - Assign cell type label based on expert knowledge
4. Validate assignments with additional markers
5. Refine cluster resolution if needed

**Success Metrics:**
- Agreement with known biology (when available)
- Consistency of marker expression within clusters
- Expert validation and consensus
- Reproducibility across analyses

**Limitations:**
- Subjective and labor-intensive
- Requires extensive biological expertise
- Time-consuming (hours to days per dataset)
- Difficult to reproduce across labs
- Struggles with closely related cell types
- Inconsistent annotation conventions
- Cannot easily leverage knowledge from previous studies

---

#### ML/AI Approach: Automated Reference-Based Classification

**Key Innovation: SingleR**

<cite>Aran et al. (2019)</cite> developed **SingleR** (Single-cell Recognition), an automated method that leverages reference datasets to annotate new cells.

#### Method Details

**Algorithm:** Reference-based classification using rank correlations

**Key Components:**

1. **Training Phase (on reference dataset):**
   - Given reference with known cell type labels
   - Identify marker genes for each cell type using differential expression
   - Can use bulk RNA-seq or single-cell references
   - Stores gene expression signatures for each type

2. **Prediction Phase (on query dataset):**
   - For each query cell:
     - Compute Spearman correlation with each reference cell type
     - Use only marker genes specific to relevant cell types
   - Assign label with highest correlation score

3. **Fine-tuning Phase:**
   - For each cell, identify top-scoring labels
   - Perform second round of prediction using only highly-ranked labels
   - Increases confidence in final assignments
   - Can reject low-confidence predictions

**Traditional Comparison:**
Replaces the entire manual workflow described above with automated computation.

#### Assessment of Success

**Evaluation Strategies:**

1. **Concordance with Manual Annotations:**
   - When ground truth available, measure agreement
   - Metrics: Accuracy, F1-score, balanced accuracy

2. **Cross-Reference Validation:**
   - Test with multiple independent reference datasets
   - Measure consistency of predictions across references

3. **Benchmark Studies:**
   - Compare SingleR against other automated methods
   - Evaluate on diverse datasets (different tissues, technologies)

**Benchmark Results from <cite>Sun et al. (2020)</cite>:**

Evaluated 10 cell type annotation methods including:
- SingleR
- Seurat (reference mapping)
- scmap
- CHETAH
- SingleCellNet
- scPred
- Others

**Key Findings:**
- SingleR ranked among **top-performing methods** for inter-dataset prediction accuracy
- Maintained **robust performance** when genes were filtered
- **Resistant to downsampling** (worked well even with fewer cells)
- Good balance of accuracy and computational efficiency
- Particularly strong for well-characterized cell types with good references

**Advantages Over Manual Annotation:**
- **Speed:** Seconds to minutes vs. hours to days
- **Reproducibility:** Same data → same results across users
- **Scalability:** Handles datasets with millions of cells
- **Knowledge transfer:** Leverages prior expert annotations
- **Consistency:** Uses standardized cell type ontologies
- **Objectivity:** Reduces human bias and subjectivity

**Limitations:**
- Dependent on reference quality
- May struggle with novel cell types not in reference
- Performance degrades with reference-query mismatch (e.g., different species, tissues)
- Cannot always distinguish very closely related subtypes

#### Supporting References

**Primary Citation:**
Aran, D., Looney, A.P., Liu, L., Wu, E., Fong, V., Hsu, A., Chak, S., Naikawadi, R.P., Wolters, P.J., Abate, A.R., Butte, A.J., & Bhattacharya, M. (2019). Reference-based analysis of lung single-cell sequencing reveals a transitional profibrotic macrophage. *Nature Immunology*, 20(2):163-172. https://doi.org/10.1038/s41590-018-0276-y

**Key Excerpts:**
- "We present SingleR, a novel computational method for unbiased cell type recognition of scRNA-seq"
- "SingleR leverages reference transcriptomic datasets of pure cell types to infer the cell of origin of each of the single cells independently"
- Demonstrated on lung scRNA-seq data, identifying novel transitional cell state

**Benchmark Study:**
Sun, Q., Zhao, X., Li, R., Liu, X., Zhang, X., Wang, C., & Sun, X. (2020). Evaluation of Cell Type Annotation R Packages on Single-cell RNA-seq Data. *Genomics, Proteomics & Bioinformatics*, 18(6):711-724. https://doi.org/10.1016/j.gpb.2020.07.004

**Key Findings from Benchmark:**
- "Methods such as Seurat, SingleR, CP, RPC, and SingleCellNet performed well"
- "Seurat, SingleR, CP, and RPC were more robust against downsampling"
- Comprehensive evaluation across multiple datasets and annotation scenarios

**Related Methods:**

**scPred:**
Alquicira-Hernandez, J., Sathe, A., Ji, H.P., Nguyen, Q., & Powell, J.E. (2019). scPred: accurate supervised method for cell-type classification from single-cell RNA-seq data. *Genome Biology*, 20:264. https://doi.org/10.1186/s13059-019-1862-5

**SingleCellNet:**
Tan, Y. & Cahan, P. (2019). SingleCellNet: A Computational Tool to Classify Single Cell RNA-Seq Data Across Platforms and Across Species. *Cell Systems*, 9(2):207-213.e2. https://doi.org/10.1016/j.cels.2019.06.004

**CHETAH:**
de Kanter, J.K., Lijnzaad, P., Candelli, T., Margaritis, T., & Holstege, F.C.P. (2019). CHETAH: a selective, hierarchical cell type identification method for single-cell RNA sequencing. *Nucleic Acids Research*, 47(16):e95. https://doi.org/10.1093/nar/gkz543

---

### 2.2 Clustering with Explicit Dropout Modeling

#### Traditional Approach: Standard Clustering on Transformed Data

**Common Pipeline:**
1. **Data Transformation:**
   - Log-normalization: log₂(counts + 1)
   - Library size normalization
   - Feature selection (highly variable genes)

2. **Dimensionality Reduction:**
   - PCA (linear method)
   - t-SNE or UMAP (non-linear visualization)

3. **Clustering:**
   - k-means clustering on PCA space
   - Hierarchical clustering with various linkages
   - Graph-based clustering (Louvain, Leiden)

**Success Metrics:**
- Silhouette coefficient (cluster quality)
- Davies-Bouldin index (cluster separation)
- Visual inspection of cluster separation
- Biological validation via marker genes

**Critical Limitation:**
These methods **treat zero counts as true zeros**, but scRNA-seq has pervasive **"dropout events"** — biological transcripts present in cells but not captured due to:
- Low RNA capture efficiency
- Stochastic sampling in library preparation
- Sequencing depth limitations
- Technical noise

Result: Many zeros are **false zeros** (technical noise) rather than biological absence, obscuring true cell-to-cell relationships.

---

#### ML/AI Approach: Model-Based Deep Learning with Explicit Dropout Handling

**Key Innovation: scDeepCluster**

<cite>Tian et al. (2019)</cite> developed **scDeepCluster**, which simultaneously learns representations and discovers clusters while explicitly modeling dropout events.

#### Method Details

**Algorithm:** Deep embedded clustering with zero-inflated negative binomial (ZINB) modeling

**Architecture:**

```
Input Layer (gene expression counts)
        ↓
Encoder Network (neural network)
        ↓
Latent Representation z
        ↓
[Split into two paths]
        ↓                           ↓
Decoder Network          Clustering Layer
(reconstructs expression)  (soft cluster assignments)
```

**Key Components:**

1. **Autoencoder for Denoising:**
   - **Encoder:** Compresses gene expression to low-dimensional latent space
   - **Decoder:** Reconstructs expression from latent representation
   - Uses zero-inflated negative binomial likelihood (models dropouts explicitly)

2. **Clustering in Latent Space:**
   - Learnable cluster centroids in latent space
   - Soft cluster assignments (probability distribution over clusters)
   - Student's t-distribution for similarity to centroids

3. **Joint Optimization:**
   - Minimizes reconstruction loss (how well expression is reconstructed)
   - Minimizes clustering loss (how well-separated clusters are)
   - Trains both objectives simultaneously

**Handling Dropouts:**
The ZINB distribution has two components:
- **Zero-inflation component:** Models technical dropouts (false zeros)
- **Negative binomial component:** Models biological variation
- Model learns to distinguish biological zeros from technical zeros

**Why This Works:**
- Denoising autoencoder learns true biological signal beneath technical noise
- Latent space captures biological variation while filtering technical artifacts
- Joint training ensures clustering uses denoised representations
- ZINB explicitly models the dropout process

#### Traditional Comparisons

Study compared scDeepCluster against:

1. **PCA + k-means:** Linear dimensionality reduction + clustering
2. **t-SNE + k-means:** Non-linear visualization + clustering
3. **SIMLR:** Similarity-based learning method
4. **CIDR:** Clustering through imputation and dimensionality reduction
5. **DCA + k-means:** Denoising autoencoder followed by k-means
6. **DEC:** Deep embedded clustering (without scRNA-seq-specific modeling)

#### Assessment of Success

**Evaluation Strategy:**
- Tested on simulated data (known ground truth)
- Tested on 4 real scRNA-seq datasets from different platforms:
  - 10X Genomics (droplet-based)
  - Smart-seq2 (plate-based, full-length)
  - inDrop (droplet-based)
  - Drop-seq (droplet-based)

**Performance Metrics:**

1. **Normalized Mutual Information (NMI):**
   - Measures information shared between predicted and true labels
   - Range: [0, 1], higher is better
   - Corrects for chance agreement

2. **Adjusted Rand Index (ARI):**
   - Measures similarity of two clusterings
   - Adjusted for random chance
   - Range: [-1, 1], higher is better

3. **Clustering Accuracy (CA):**
   - Proportion of cells assigned to correct cluster
   - Requires Hungarian algorithm to match cluster IDs

4. **Computational Scalability:**
   - Wall-clock time as function of sample size
   - Memory usage

**Key Findings:**

**Performance:**
- scDeepCluster **outperformed all competing methods** on NMI, ARI, and CA
- Improvement particularly pronounced on:
  - High-dropout datasets
  - Datasets with rare cell populations
  - Large-scale datasets

**Specific Results (Example from Paper):**
On 10X PBMC dataset (68,000 cells):
- scDeepCluster NMI: **0.76**
- PCA + k-means NMI: 0.52
- SIMLR NMI: 0.68
- CIDR NMI: 0.63

**Scalability:**
- Computational time scaled **linearly with sample size** (O(n))
- Critical for datasets with >100,000 cells
- Competing methods often showed quadratic scaling

**Visualization:**
- Latent space showed **clearer separation** of cell types
- Better preservation of biological structure
- Reduced batch effects in latent representation

#### Why Deep Learning Outperformed Traditional Methods

1. **Explicit Dropout Modeling:**
   - ZINB likelihood directly accounts for false zeros
   - Traditional methods (PCA, k-means) assume all zeros are real

2. **Non-linear Transformations:**
   - Deep networks capture complex gene relationships
   - PCA limited to linear combinations

3. **Joint Optimization:**
   - Simultaneously optimizes reconstruction and clustering
   - Traditional pipeline: separate steps with no feedback

4. **Learned Representations:**
   - Network learns optimal features for the task
   - Hand-crafted features (HVGs, PCA) may miss important signals

#### Supporting References

**Primary Citation:**
Tian, T., Wan, J., Song, Q., & Wei, Z. (2019). Clustering single-cell RNA-seq data with a model-based deep learning approach. *Nature Machine Intelligence*, 1(4):191-198. https://doi.org/10.1038/s42256-019-0037-0

**Key Excerpts:**
- "scDeepCluster, a single-cell model-based deep embedded clustering method, which simultaneously learns feature representation and clustering via explicit modelling of scRNA-seq data generation"
- "Based on testing extensive simulated data and real datasets from four representative single-cell sequencing platforms, scDeepCluster outperformed state-of-the-art methods"
- "Exhibited improved scalability, with running time increasing linearly with sample size"

**Follow-up Work (Constrained Clustering):**
Tian, T., Zhang, J., Lin, X., Wei, Z., & Hakonarson, H. (2021). Model-based deep embedding for constrained clustering analysis of single cell RNA-seq data. *Nature Communications*, 12:1873. https://doi.org/10.1038/s41467-021-22008-3

Extended scDeepCluster with biological constraints and semi-supervised learning.

**Related Deep Learning Clustering Methods:**

**Deep Embedded Clustering (foundational method):**
Xie, J., Girshick, R., & Farhadi, A. (2016). Unsupervised deep embedding for clustering analysis. *Proceedings of the 33rd International Conference on Machine Learning*, PMLR 48:478-487.

**DCA (Denoising Autoencoder for scRNA-seq):**
Eraslan, G., Simon, L.M., Mircea, M., Mueller, N.S., & Theis, F.J. (2019). Single-cell RNA-seq denoising using a deep count autoencoder. *Nature Communications*, 10:390. https://doi.org/10.1038/s41467-018-07931-2

---

## 3. Batch Correction Methods (Non-RUV)

Batch effects are systematic technical variation between experimental batches. While numerous batch correction methods exist, **none specifically apply AI/ML to enhance RUV-based approaches**. This section documents existing methods to clarify which do and don't use ML.

---

### 3.1 Traditional Statistical Batch Correction

#### ComBat and ComBat-seq

**Original Method:** <cite>Johnson et al. (2007)</cite> - ComBat for microarrays

**Approach:** Empirical Bayes shrinkage

**Method:**
1. Model batch effects as additive and multiplicative factors:
   - Gene expression = biological signal + batch effect + error
2. Estimate batch effect parameters for each batch
3. Shrink batch effect estimates toward overall means using empirical Bayes
4. Adjust data by subtracting estimated batch effects

**Not Machine Learning Because:**
- Uses closed-form statistical estimation (empirical Bayes)
- No iterative optimization or gradient descent
- No learned representations or feature extraction
- Parameters have direct statistical interpretation

**Extension to RNA-seq:** <cite>Zhang et al. (2020)</cite> - ComBat-seq

**Innovation:** Adapted ComBat for count data using negative binomial regression

**References:**
- Johnson, W.E., Li, C., & Rabinovic, A. (2007). Adjusting batch effects in microarray expression data using empirical Bayes methods. *Biostatistics*, 8(1):118-127. https://doi.org/10.1093/biostatistics/kxj037
- Zhang, Y., Parmigiani, G., & Johnson, W.E. (2020). ComBat-seq: batch effect adjustment for RNA-seq count data. *NAR Genomics and Bioinformatics*, 2(3):lqaa078. https://doi.org/10.1093/nargab/lqaa078

---

#### Harmony

**Method:** <cite>Korsunsky et al. (2019)</cite>

**Approach:** Iterative clustering with batch-aware correction

**Algorithm:**
1. Perform PCA on combined datasets
2. Apply soft k-means clustering in PCA space
3. For each cluster, compute batch-specific centroids
4. Adjust cell positions to align batch centroids within clusters
5. Iterate until convergence

**Not Deep Learning Because:**
- Uses k-means clustering (classical algorithm)
- Iterative but deterministic optimization
- No neural networks or learned transformations
- Based on linear dimensionality reduction (PCA)

**Why It's Effective:**
- Fast and scalable
- Preserves biological variation while removing batch effects
- Works across different technologies
- Integrates multiple datasets simultaneously

**Reference:**
Korsunsky, I., Millard, N., Fan, J., Slowikowski, K., Zhang, F., Wei, K., Baglaenko, Y., Brenner, M., Loh, P., & Raychaudhuri, S. (2019). Fast, sensitive and accurate integration of single-cell data with Harmony. *Nature Methods*, 16(12):1289-1296. https://doi.org/10.1038/s41592-019-0619-0

---

#### Seurat Integration

**Method:** <cite>Stuart et al. (2019)</cite>

**Approach:** Canonical correlation analysis (CCA) with mutual nearest neighbors (MNN)

**Algorithm:**
1. Identify shared sources of variation using CCA
2. Find "anchor" pairs (mutual nearest neighbors) between datasets
3. Use anchors to harmonize datasets
4. Construct integrated low-dimensional representation

**Not Machine Learning Because:**
- CCA is a linear statistical method
- MNN search is a graph-based algorithm
- No learned parameters or training process
- Based on well-established multivariate statistics

**Reference:**
Stuart, T., Butler, A., Hoffman, P., Hafemeister, C., Papalexi, E., Mauck, W.M. 3rd, Hao, Y., Stoeckius, M., Smibert, P., & Satija, R. (2019). Comprehensive Integration of Single-Cell Data. *Cell*, 177(7):1888-1902.e21. https://doi.org/10.1016/j.cell.2019.05.031

---

#### Mutual Nearest Neighbors (MNN)

**Method:** <cite>Haghverdi et al. (2018)</cite>

**Approach:** Graph-based batch correction

**Algorithm:**
1. Find mutual nearest neighbors between batches
2. Use MNN pairs as anchors
3. Compute batch correction vectors from MNN pairs
4. Apply Gaussian smoothing to propagate corrections
5. Adjust expression values

**Not Machine Learning:** Graph algorithms and geometric transformations

**Reference:**
Haghverdi, L., Lun, A.T.L., Morgan, M.D., & Marioni, J.C. (2018). Batch effects in single-cell RNA-sequencing data are corrected by matching mutual nearest neighbors. *Nature Biotechnology*, 36:421–427. https://doi.org/10.1038/nbt.4091

---

### 3.2 Deep Learning Approach: scVI

#### Method Overview

<cite>Lopez et al. (2018)</cite> developed **scVI** (single-cell Variational Inference), which uses deep learning for single-cell data modeling.

**Architecture:** Variational Autoencoder (VAE)

**Key Components:**

1. **Encoder (Inference Network):**
   - Input: Gene expression counts + batch label
   - Output: Parameters of latent distribution q(z|x)
   - Neural network with 1-2 hidden layers

2. **Latent Space:**
   - Low-dimensional representation (10-30 dimensions)
   - Captures biological variation
   - Batch effects modeled separately

3. **Decoder (Generative Model):**
   - Input: Latent variable z + batch label
   - Output: Parameters of expression distribution
   - Uses zero-inflated negative binomial (ZINB) likelihood
   - Includes library size as latent variable

**How Batch Correction Works:**

- Batch identity provided as known covariate to model
- Encoder learns to create latent representations that capture biology
- Decoder can generate expression for any batch
- By sampling z and changing batch label, can generate batch-corrected data
- Batch effects captured in separate parameters, not in z

**Important Distinction:**
- scVI uses deep learning (VAE) for **data modeling**
- Batch correction is an **indirect benefit** of learning good latent representations
- Primary innovation: probabilistic modeling of scRNA-seq with neural networks
- Not specifically designed for batch correction (unlike ComBat, Harmony, etc.)

**Traditional Comparison:**
- Compared against factor analysis
- Compared against ZINB-WaVE (statistical model)
- Evaluated on clustering and visualization tasks

**Success Metrics:**
- Log-likelihood (model fit)
- Clustering accuracy
- Dimensionality reduction quality
- Batch mixing in latent space

**Performance:**
- Achieved better log-likelihood than statistical alternatives
- Created well-mixed latent spaces (reduced batch effects)
- Enabled accurate imputation of dropout events
- Scalable to large datasets

**References:**

**Primary Citation:**
Lopez, R., Regier, J., Cole, M.B., Jordan, M.I., & Yosef, N. (2018). Deep generative modeling for single-cell transcriptomics. *Nature Methods*, 15(12):1053-1058. https://doi.org/10.1038/s41592-018-0229-2

**Extension (Multi-omics):**
Gayoso, A., Steier, Z., Lopez, R., Regier, J., Nazor, K.L., Streets, A., & Yosef, N. (2021). Joint probabilistic modeling of single-cell multi-omic data with totalVI. *Nature Methods*, 18(3):272-282. https://doi.org/10.1038/s41592-020-01050-x

---

### 3.3 Summary: ML in Batch Correction

**Methods Using Statistical Approaches (NOT ML/AI):**
- ComBat / ComBat-seq: Empirical Bayes
- Harmony: Iterative clustering
- Seurat: CCA + MNN
- MNN: Graph algorithms
- **RUV methods (all variants):** Factor analysis, linear models

**Methods Using Deep Learning:**
- scVI: VAE with ZINB likelihood
  - But batch correction is indirect benefit, not primary ML innovation

**Critical Gap:**
**No method applies ML/AI specifically to optimize RUV-based batch correction** despite RUV's strong theoretical foundation and empirical success.

---

## 4. General RNA-seq Processing Tasks

This section briefly covers other RNA-seq analysis tasks where ML has been applied, demonstrating the broad applicability of AI/ML to transcriptomics.

---

### 4.1 Expression Prediction from Epigenetic Data

**Traditional Approach:** Linear regression models relating chromatin features to expression

**ML Approaches:**
- Deep neural networks (CNNs for sequence data)
- Gradient boosting machines (XGBoost, LightGBM)
- Support vector machines with non-linear kernels

**Success Metrics:**
- Correlation between predicted and observed expression (Pearson r)
- Prediction accuracy on held-out chromosomes
- Generalization across cell types

**Example Reference:**
Singh, R., Lanchantin, J., Robins, G., & Qi, Y. (2016). DeepChrome: deep-learning for predicting gene expression from histone modifications. *Bioinformatics*, 32(17):i639-i648. https://doi.org/10.1093/bioinformatics/btw427

---

### 4.2 Transcript Quantification

**Traditional Approach:** Alignment-based quantification (RSEM, Salmon) using expectation-maximization

**ML Approach:** Neural networks for alignment-free quantification from k-mer counts

**Advantage:** Faster computation, can handle novel transcripts

---

### 4.3 Quality Filtering

**Traditional Approach:** Hard thresholds on metrics
- Number of reads per sample
- Percentage of mitochondrial genes
- Library size cutoffs

**ML Approach:** Probabilistic outlier identification

<cite>Mangiola et al. (2021)</cite> developed methods using:
- Mixture models for quality score distributions
- Anomaly detection algorithms
- Machine learning classifiers trained on expert QC decisions

**Success Metrics:**
- Concordance with manual QC
- Downstream analysis quality (reduced artifacts)
- Ability to detect subtle QC issues

**Reference:**
Mangiola, S., Papenfuss, A.T., & Thomas, T. (2021). Probabilistic outlier identification for RNA sequencing generalized linear models. *NAR Genomics and Bioinformatics*, 3(1):lqaa107. https://doi.org/10.1093/nargab/lqaa107

---

## 5. Summary and Implications

### 5.1 What We've Learned

**ML/AI Successfully Applied in RNA-seq for:**

1. **Gene Selection:**
   - Random Forests outperform DE in 9/12 datasets
   - VAEs enable novel synthetic sample generation
   - Deep learning captures non-linear gene interactions

2. **Single-Cell Analysis:**
   - Automated cell type annotation (SingleR) replaces manual workflow
   - Deep clustering (scDeepCluster) explicitly models dropouts
   - Achieves superior accuracy with linear scalability

3. **Data Modeling:**
   - VAEs (scVAE, scVI) provide probabilistic frameworks
   - Better model fit than classical statistical approaches
   - Enable generation of synthetic data and imputation

4. **Batch Correction (partial):**
   - scVI uses deep learning but correction is indirect
   - Most methods (ComBat, Harmony, Seurat) remain statistical

### 5.2 Pattern Recognition

**What Makes ML Successful:**
- Non-linear modeling of complex biological relationships
- Automatic feature learning (no hand-crafting required)
- Joint optimization of multiple objectives
- Leverages large datasets effectively
- Captures gene-gene interactions implicitly

**When ML Outperforms Traditional Methods:**
- High-dimensional, complex data (typical in genomics)
- Non-linear relationships between features
- Large training datasets available
- Need to capture interactions between variables
- Benefit from transfer learning across datasets

### 5.3 Critical Gap: No AI/ML for RUV

**Why This Matters:**

1. **RUV Success:** Methods work well, but require expert knowledge
2. **Manual Bottleneck:** Parameter selection is time-consuming
3. **Proven ML Value:** Success in adjacent tasks shows feasibility
4. **Technical Need:** Multi-center studies need robust normalization
5. **Community Readiness:** Bioinformatics increasingly adopts ML

**Specific RUV Steps That Could Benefit from AI/ML:**

| RUV Step | Current Approach | ML Opportunity | Evidence from Related Work |
|----------|------------------|----------------|----------------------------|
| NCG Selection | Manual/statistical | Supervised classification | RF gene selection (Wenric 2018) |
| PRPS Construction | Manual grouping | Deep clustering | scDeepCluster (Tian 2019) |
| K Parameter | Trial and error | Bayesian optimization | - |
| Unknown Batch Detection | Visual inspection | Anomaly detection | VAE latent structure (Way 2017) |
| Cross-Study Transfer | Independent normalization | Transfer learning | SingleR transfer (Aran 2019) |

### 5.4 Implications for Research

**This Analysis Demonstrates:**

1. **Technical Feasibility:** ML works on similar RNA-seq tasks
2. **Clear Need:** Manual RUV workflows are bottlenecks
3. **Available Tools:** Deep learning frameworks mature and accessible
4. **Data Availability:** TCGA and other resources for training
5. **Community Acceptance:** ML methods adopted when properly validated

**Research Opportunity:**
The documented success of AI/ML in adjacent RNA-seq analysis tasks, combined with the complete absence of such applications to RUV normalization, represents a significant gap and a high-impact research opportunity.

---

## References

### Gene Selection and Feature Extraction

1. Wenric, S. & Shemirani, R. (2018). Using Supervised Learning Methods for Gene Selection in RNA-Seq Case-Control Studies. *Frontiers in Genetics*, 9:297. https://doi.org/10.3389/fgene.2018.00297

2. Ching, T., Zhu, X., & Garmire, L.X. (2018). Cox-nnet: An artificial neural network method for prognosis prediction of high-throughput omics data. *PLoS Computational Biology*, 14(4):e1006076. https://doi.org/10.1371/journal.pcbi.1006076

3. Swan, A.L., Mobasheri, A., Allaway, D., Liddell, S., & Bacardit, J. (2013). Application of machine learning to proteomics data: classification and biomarker identification in postgenomics biology. *OMICS*, 17(12):595-610. https://doi.org/10.1089/omi.2013.0017

### Variational Autoencoders

4. Kingma, D.P. & Welling, M. (2013). Auto-encoding variational Bayes. *arXiv preprint* arXiv:1312.6114. https://arxiv.org/abs/1312.6114

5. Grønbech, C.H., Vording, M.F., Timshel, P.N., Sønderby, C.K., Pers, T.H., & Winther, O. (2020). scVAE: Variational auto-encoders for single-cell gene expression data. *Bioinformatics*, 36(16):4415-4422. https://doi.org/10.1093/bioinformatics/btaa293

6. Way, G.P. & Greene, C.S. (2017). Extracting a biologically relevant latent space from cancer transcriptomes with variational autoencoders. *Pacific Symposium on Biocomputing*, 23:80-91. https://doi.org/10.1142/9789813235533_0008

7. Lopez, R., Regier, J., Cole, M.B., Jordan, M.I., & Yosef, N. (2018). Deep generative modeling for single-cell transcriptomics. *Nature Methods*, 15(12):1053-1058. https://doi.org/10.1038/s41592-018-0229-2

8. Gayoso, A., Steier, Z., Lopez, R., Regier, J., Nazor, K.L., Streets, A., & Yosef, N. (2021). Joint probabilistic modeling of single-cell multi-omic data with totalVI. *Nature Methods*, 18(3):272-282. https://doi.org/10.1038/s41592-020-01050-x

### Single-Cell Clustering

9. Tian, T., Wan, J., Song, Q., & Wei, Z. (2019). Clustering single-cell RNA-seq data with a model-based deep learning approach. *Nature Machine Intelligence*, 1(4):191-198. https://doi.org/10.1038/s42256-019-0037-0

10. Tian, T., Zhang, J., Lin, X., Wei, Z., & Hakonarson, H. (2021). Model-based deep embedding for constrained clustering analysis of single cell RNA-seq data. *Nature Communications*, 12:1873. https://doi.org/10.1038/s41467-021-22008-3

11. Xie, J., Girshick, R., & Farhadi, A. (2016). Unsupervised deep embedding for clustering analysis. *Proceedings of the 33rd International Conference on Machine Learning*, PMLR 48:478-487.

12. Eraslan, G., Simon, L.M., Mircea, M., Mueller, N.S., & Theis, F.J. (2019). Single-cell RNA-seq denoising using a deep count autoencoder. *Nature Communications*, 10:390. https://doi.org/10.1038/s41467-018-07931-2

### Cell Type Annotation

13. Aran, D., Looney, A.P., Liu, L., Wu, E., Fong, V., Hsu, A., Chak, S., Naikawadi, R.P., Wolters, P.J., Abate, A.R., Butte, A.J., & Bhattacharya, M. (2019). Reference-based analysis of lung single-cell sequencing reveals a transitional profibrotic macrophage. *Nature Immunology*, 20(2):163-172. https://doi.org/10.1038/s41590-018-0276-y

14. Sun, Q., Zhao, X., Li, R., Liu, X., Zhang, X., Wang, C., & Sun, X. (2020). Evaluation of Cell Type Annotation R Packages on Single-cell RNA-seq Data. *Genomics, Proteomics & Bioinformatics*, 18(6):711-724. https://doi.org/10.1016/j.gpb.2020.07.004

15. Alquicira-Hernandez, J., Sathe, A., Ji, H.P., Nguyen, Q., & Powell, J.E. (2019). scPred: accurate supervised method for cell-type classification from single-cell RNA-seq data. *Genome Biology*, 20:264. https://doi.org/10.1186/s13059-019-1862-5

16. Tan, Y. & Cahan, P. (2019). SingleCellNet: A Computational Tool to Classify Single Cell RNA-Seq Data Across Platforms and Across Species. *Cell Systems*, 9(2):207-213.e2. https://doi.org/10.1016/j.cels.2019.06.004

17. de Kanter, J.K., Lijnzaad, P., Candelli, T., Margaritis, T., & Holstege, F.C.P. (2019). CHETAH: a selective, hierarchical cell type identification method for single-cell RNA sequencing. *Nucleic Acids Research*, 47(16):e95. https://doi.org/10.1093/nar/gkz543

### Batch Correction Methods

18. Johnson, W.E., Li, C., & Rabinovic, A. (2007). Adjusting batch effects in microarray expression data using empirical Bayes methods. *Biostatistics*, 8(1):118-127. https://doi.org/10.1093/biostatistics/kxj037

19. Zhang, Y., Parmigiani, G., & Johnson, W.E. (2020). ComBat-seq: batch effect adjustment for RNA-seq count data. *NAR Genomics and Bioinformatics*, 2(3):lqaa078. https://doi.org/10.1093/nargab/lqaa078

20. Korsunsky, I., Millard, N., Fan, J., Slowikowski, K., Zhang, F., Wei, K., Baglaenko, Y., Brenner, M., Loh, P., & Raychaudhuri, S. (2019). Fast, sensitive and accurate integration of single-cell data with Harmony. *Nature Methods*, 16(12):1289-1296. https://doi.org/10.1038/s41592-019-0619-0

21. Stuart, T., Butler, A., Hoffman, P., Hafemeister, C., Papalexi, E., Mauck, W.M. 3rd, Hao, Y., Stoeckius, M., Smibert, P., & Satija, R. (2019). Comprehensive Integration of Single-Cell Data. *Cell*, 177(7):1888-1902.e21. https://doi.org/10.1016/j.cell.2019.05.031

22. Haghverdi, L., Lun, A.T.L., Morgan, M.D., & Marioni, J.C. (2018). Batch effects in single-cell RNA-sequencing data are corrected by matching mutual nearest neighbors. *Nature Biotechnology*, 36:421–427. https://doi.org/10.1038/nbt.4091

### Quality Control

23. Mangiola, S., Papenfuss, A.T., & Thomas, T. (2021). Probabilistic outlier identification for RNA sequencing generalized linear models. *NAR Genomics and Bioinformatics*, 3(1):lqaa107. https://doi.org/10.1093/nargab/lqaa107

24. Ilicic, T., Kim, J.K., Kolodziejczyk, A.A., Bagger, F.O., McCarthy, D.J., Marioni, J.C., & Teichmann, S.A. (2016). Classification of low quality cells from single-cell RNA-seq data. *Genome Biology*, 17:29. https://doi.org/10.1186/s13059-016-0888-1

### General ML in Genomics Reviews

25. Eraslan, G., Avsec, Ž., Gagneur, J., & Theis, F.J. (2019). Deep learning: new computational modelling techniques for genomics. *Nature Reviews Genetics*, 20:389–403. https://doi.org/10.1038/s41576-019-0122-6

26. Zou, J., Huss, M., Abid, A., Mohammadi, P., Torkamani, A., & Telenti, A. (2019). A primer on deep learning in genomics. *Nature Genetics*, 51:12–18. https://doi.org/10.1038/s41588-018-0295-5

27. Camacho, D.M., Collins, K.M., Powers, R.K., Costello, J.C., & Collins, J.J. (2018). Next-Generation Machine Learning for Biological Networks. *Cell*, 173(7):1581-1592. https://doi.org/10.1016/j.cell.2018.05.015

---

**Document Status:** Complete  
**Part of Series:** AI-Enhanced RUV Normalization Research Documents  
**Related Documents:** Part 1 (Current State), Part 2 (Research Proposal)
